El superuser creado es: 
usuario: tobias
contraseña: tobias01

En los templates de mi app 'Shopping' se encuentran todos los html a los que dirigen las url. 

Creé modelos (en models.py) sobre las distintas secciones que puede tener un shopping.
en urls.py de la app se encuentran todos los path para navegar en la web, en urls.py del proyecto se encuentra el path de admin y se incluyen las url de la app.

en forms.py hice un formulario para que los usuarios puedan registrarse en la web.

en views.py estan todas las vistas de mi pagina web, y sus redirecciones.