from django.contrib import admin
from .models import * 

admin.site.register(Locales)
admin.site.register(PatioComidas)
admin.site.register(Cine)
admin.site.register(Promos)
